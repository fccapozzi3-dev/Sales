import { useEffect, useMemo, useState } from 'react'
import './app.css'

function uid() {
  return Math.random().toString(36).slice(2, 9)
}

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}

function App() {
  const [tab, setTab] = useState('dashboard')
  const [contacts, setContacts] = useState(() => load('otp_contacts', []))
  const [quotes, setQuotes] = useState(() => load('otp_quotes', []))
  const [settings, setSettings] = useState(() => load('otp_settings', { customerOrderFormUrl: '' }))
  const [contactForm, setContactForm] = useState({ name: '', phone: '', email: '' })
  const [quoteForm, setQuoteForm] = useState({ contactId: '', product: '', quantity: '', price: '' })

  useEffect(() => localStorage.setItem('otp_contacts', JSON.stringify(contacts)), [contacts])
  useEffect(() => localStorage.setItem('otp_quotes', JSON.stringify(quotes)), [quotes])
  useEffect(() => localStorage.setItem('otp_settings', JSON.stringify(settings)), [settings])

  const revenue = useMemo(() => quotes.reduce((sum, q) => sum + Number(q.total || 0), 0), [quotes])

  function addContact() {
    if (!contactForm.name.trim()) return alert('Enter a contact name')
    setContacts(prev => [{ id: uid(), ...contactForm }, ...prev])
    setContactForm({ name: '', phone: '', email: '' })
  }

  function deleteContact(id) {
    setContacts(prev => prev.filter(c => c.id !== id))
  }

  function saveQuote() {
    const { contactId, product, quantity, price } = quoteForm
    if (!contactId || !product || !quantity || !price) return alert('Fill out all quote fields')
    const contact = contacts.find(c => c.id === contactId)
    const total = Number(quantity) * Number(price)
    setQuotes(prev => [{
      id: uid(), contactId, contactName: contact?.name || 'Unknown',
      product, quantity: Number(quantity), price: Number(price), total
    }, ...prev])
    setQuoteForm({ contactId: '', product: '', quantity: '', price: '' })
    setTab('history')
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <h1>OilTrackPro</h1>
        <p>Simple quote and contact tracker</p>
      </header>

      <nav className="tabs">
        {['dashboard','contacts','quote','history','settings'].map(key => (
          <button key={key} className={tab === key ? 'tab active' : 'tab'} onClick={() => setTab(key)}>
            {key[0].toUpperCase() + key.slice(1)}
          </button>
        ))}
      </nav>

      {tab === 'dashboard' && (
        <section className="card-grid">
          <div className="card"><h2>Contacts</h2><div className="metric">{contacts.length}</div></div>
          <div className="card"><h2>Quotes</h2><div className="metric">{quotes.length}</div></div>
          <div className="card"><h2>Total quoted</h2><div className="metric">${revenue.toFixed(2)}</div></div>
          <div className="card">
            <h2>Customer order form</h2>
            {settings.customerOrderFormUrl ? (
              <a className="link-button" href={settings.customerOrderFormUrl} target="_blank" rel="noreferrer">Open form</a>
            ) : <p className="muted">Paste the live GitHub Pages URL in Settings.</p>}
          </div>
        </section>
      )}

      {tab === 'contacts' && (
        <section className="card">
          <h2>Add contact</h2>
          <div className="form-grid">
            <input placeholder="Name" value={contactForm.name} onChange={e => setContactForm({ ...contactForm, name: e.target.value })} />
            <input placeholder="Phone" value={contactForm.phone} onChange={e => setContactForm({ ...contactForm, phone: e.target.value })} />
            <input placeholder="Email" value={contactForm.email} onChange={e => setContactForm({ ...contactForm, email: e.target.value })} />
            <button className="primary" onClick={addContact}>Save contact</button>
          </div>
          <div className="stack">
            {contacts.length === 0 && <p className="muted">No contacts yet.</p>}
            {contacts.map(c => (
              <div className="list-card" key={c.id}>
                <div><strong>{c.name}</strong><div>{c.phone || '—'}</div><div>{c.email || '—'}</div></div>
                <button className="danger small" onClick={() => deleteContact(c.id)}>Delete</button>
              </div>
            ))}
          </div>
        </section>
      )}

      {tab === 'quote' && (
        <section className="card">
          <h2>Build quote</h2>
          <div className="form-grid">
            <select value={quoteForm.contactId} onChange={e => setQuoteForm({ ...quoteForm, contactId: e.target.value })}>
              <option value="">Select contact</option>
              {contacts.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <input placeholder="Product" value={quoteForm.product} onChange={e => setQuoteForm({ ...quoteForm, product: e.target.value })} />
            <input type="number" placeholder="Quantity" value={quoteForm.quantity} onChange={e => setQuoteForm({ ...quoteForm, quantity: e.target.value })} />
            <input type="number" placeholder="Price per gallon" value={quoteForm.price} onChange={e => setQuoteForm({ ...quoteForm, price: e.target.value })} />
            <button className="primary" onClick={saveQuote}>Save quote</button>
          </div>
        </section>
      )}

      {tab === 'history' && (
        <section className="card">
          <h2>Quote history</h2>
          <div className="stack">
            {quotes.length === 0 && <p className="muted">No quotes saved yet.</p>}
            {quotes.map(q => (
              <div className="list-card" key={q.id}>
                <div><strong>{q.product}</strong><div>Contact: {q.contactName}</div><div>{q.quantity} gal × ${q.price.toFixed(2)}</div></div>
                <div className="quote-total">${q.total.toFixed(2)}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {tab === 'settings' && (
        <section className="card">
          <h2>Settings</h2>
          <label className="label">Customer Order Form URL</label>
          <input placeholder="https://yourname.github.io/repo/customer-order-form.html" value={settings.customerOrderFormUrl} onChange={e => setSettings({ ...settings, customerOrderFormUrl: e.target.value })} />
          <p className="muted">Paste the live GitHub Pages URL for customer-order-form.html here.</p>
        </section>
      )}
    </div>
  )
}

export default App
