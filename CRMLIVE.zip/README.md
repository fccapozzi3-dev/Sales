# OilTrackPro live starter

## Files
- `src/App.jsx` = main React app
- `src/main.jsx` = Vite entry file
- `src/app.css` = styles
- `customer-order-form.html` = public customer form page

## Get it running
```bash
npm install
npm run dev
```

## To go live
1. Put these files in a GitHub repo
2. Turn on GitHub Pages
3. Make sure `customer-order-form.html` is published
4. Copy its live URL
5. Paste that URL into the app Settings tab
